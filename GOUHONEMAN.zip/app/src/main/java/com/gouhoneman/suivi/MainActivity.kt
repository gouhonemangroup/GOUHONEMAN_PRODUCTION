package com.gouhoneman.suivi

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.JavascriptInterface
import android.webkit.JsResult
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private var pendingData: String = ""
    private var fileCallback: ValueCallback<Array<Uri>>? = null

    // Enregistrement de la sauvegarde JSON : sélecteur de fichiers Android
    private val createDoc = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                contentResolver.openOutputStream(uri, "wt")?.use {
                    it.write(pendingData.toByteArray(Charsets.UTF_8))
                }
                toast("Sauvegarde enregistrée")
            } catch (e: Exception) {
                toast("Échec de l'enregistrement : " + e.message)
            }
        }
        pendingData = ""
    }

    // Choix du fichier de sauvegarde à restaurer
    private val pickFile = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        fileCallback?.onReceiveValue(if (uri != null) arrayOf(uri) else null)
        fileCallback = null
    }

    // Permission d'afficher les notifications (Android 13 et +)
    private val askNotifPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ -> }

    private fun notifGranted(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED

    inner class Bridge {
        @JavascriptInterface
        fun syncPlan(json: String) {
            Notifier.savePlan(applicationContext, json)
        }

        @JavascriptInterface
        fun notifStatus(): String = if (notifGranted()) "granted" else "denied"

        @JavascriptInterface
        fun askNotif() {
            runOnUiThread {
                if (!notifGranted()) askNotifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        @JavascriptInterface
        fun saveFile(name: String, content: String) {
            pendingData = content
            runOnUiThread { createDoc.launch(name) }
        }

        // Fichier Excel d'inscription envoyé par WhatsApp au numéro du réseau
        @JavascriptInterface
        fun sendRegistration(json: String, number: String, fileName: String) {
            runOnUiThread { shareRegistration(json, number, fileName) }
        }

        @JavascriptInterface
        fun printPage() {
            runOnUiThread {
                try {
                    val pm = getSystemService(Context.PRINT_SERVICE) as PrintManager
                    val jobName = "RESEAU_GOUHONEMAN_GROUP_Rapport"
                    pm.print(
                        jobName,
                        webView.createPrintDocumentAdapter(jobName),
                        PrintAttributes.Builder()
                            .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                            .build()
                    )
                } catch (e: Exception) {
                    toast("Impression impossible : " + e.message)
                }
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this)
        setContentView(webView)

        val s = webView.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.allowFileAccess = true

        webView.webViewClient = object : WebViewClient() {
            // Numéros de téléphone et e-mails : aucun lien ne doit s'ouvrir (ni appel, ni messagerie)
            override fun shouldOverrideUrlLoading(view: WebView, request: android.webkit.WebResourceRequest): Boolean {
                val sch = request.url.scheme?.lowercase() ?: return false
                return sch == "tel" || sch == "mailto" || sch == "sms" || sch == "smsto" || sch == "geo"
            }
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView?,
                callback: ValueCallback<Array<Uri>>?,
                params: FileChooserParams?
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                pickFile.launch("*/*")
                return true
            }

            override fun onJsAlert(
                view: WebView?, url: String?, message: String?, result: JsResult?
            ): Boolean {
                AlertDialog.Builder(this@MainActivity)
                    .setMessage(message)
                    .setPositiveButton("OK") { _, _ -> result?.confirm() }
                    .setOnCancelListener { result?.cancel() }
                    .show()
                return true
            }

            override fun onJsConfirm(
                view: WebView?, url: String?, message: String?, result: JsResult?
            ): Boolean {
                AlertDialog.Builder(this@MainActivity)
                    .setMessage(message)
                    .setPositiveButton("OK") { _, _ -> result?.confirm() }
                    .setNegativeButton("Annuler") { _, _ -> result?.cancel() }
                    .setOnCancelListener { result?.cancel() }
                    .show()
                return true
            }
        }

        // Le pont doit exister avant le chargement de la page
        webView.addJavascriptInterface(Bridge(), "Android")

        if (savedInstanceState == null && !notifGranted()) {
            askNotifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        if (savedInstanceState == null) {
            webView.loadUrl("file:///android_asset/index.html")
        } else {
            webView.restoreState(savedInstanceState)
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    private fun shareRegistration(json: String, number: String, fileName: String) {
        try {
            val o = JSONObject(json)
            val g = { k: String -> o.optString(k, "") }
            val type = if (g("type") == "structure") "Structure" else "Individu"
            val today = SimpleDateFormat("dd-MM-yyyy", Locale.FRANCE).format(Date())
            // Les dates du formulaire sont enregistrées en aaaa-mm-jj : on les écrit jj-mm-aaaa dans le fichier
            val fr = { d: String -> Regex("^(\\d{4})-(\\d{2})-(\\d{2})$").replace(d.trim(), "$3-$2-$1") }
            val values = listOf(
                fr(g("date")), type, g("structure"), g("nom"), g("prenom"), g("tel"),
                g("region"), g("prefecture"), g("commune"), g("canton"), g("localite"), today
            )
            val dir = File(cacheDir, "envoi")
            dir.mkdirs()
            dir.listFiles()?.forEach { it.delete() }
            val file = File(dir, fileName.replace(Regex("[^A-Za-z0-9._-]"), "_"))
            file.writeBytes(XlsxMaker.build(XlsxMaker.HEADERS, values))
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            val digits = number.filter { it.isDigit() }
            val text = "Inscription au réseau GOUHONEMAN GROUP : " + g("nom") + " " + g("prenom") +
                " · " + g("tel") + " · " + g("localite") + ". Fichier Excel joint."

            fun intentFor(pkg: String?): Intent {
                val i = Intent(Intent.ACTION_SEND)
                i.type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                i.putExtra(Intent.EXTRA_STREAM, uri)
                i.putExtra(Intent.EXTRA_TEXT, text)
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                if (pkg != null) {
                    i.setPackage(pkg)
                    // Ouvre directement la discussion avec le numéro du réseau
                    if (digits.isNotEmpty()) i.putExtra("jid", digits + "@s.whatsapp.net")
                }
                return i
            }

            for (pkg in listOf("com.whatsapp", "com.whatsapp.w4b")) {
                try {
                    startActivity(intentFor(pkg))
                    return
                } catch (e: Exception) {
                    // WhatsApp absent : on essaie la suite
                }
            }
            startActivity(Intent.createChooser(intentFor(null), "Envoyer le log d'inscription"))
        } catch (e: Exception) {
            toast("Envoi impossible : " + e.message)
        }
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }
}
