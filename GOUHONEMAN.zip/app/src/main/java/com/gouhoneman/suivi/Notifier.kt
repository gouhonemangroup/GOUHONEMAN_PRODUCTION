package com.gouhoneman.suivi

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import org.json.JSONArray

/** Plan de rappels envoyé par l'application web (14 jours) : stocké ici, déclenché par le système même application fermée. */
object Notifier {
    private const val PREFS = "rappels"
    private const val KEY_PLAN = "plan"
    private const val KEY_LAST = "last"
    private const val CHANNEL = "rappels_taches_v2"
    private const val OLD_CHANNEL = "rappels_elevage"
    private const val WINDOW_MS = 12L * 60 * 60 * 1000

    fun savePlan(ctx: Context, json: String) {
        try {
            JSONArray(json) // validation
            ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_PLAN, json).apply()
        } catch (e: Exception) {
            return
        }
        schedule(ctx)
    }

    private fun plan(ctx: Context): JSONArray = try {
        JSONArray(ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_PLAN, "[]"))
    } catch (e: Exception) {
        JSONArray()
    }

    private fun createChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val ch = NotificationChannel(CHANNEL, "Rappels des tâches", NotificationManager.IMPORTANCE_HIGH)
            ch.description = "Sonnerie à l'heure de chaque tâche d'élevage"
            ch.enableVibration(true)
            ch.vibrationPattern = longArrayOf(0, 500, 250, 500, 250, 500)
            ch.setSound(
                RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION),
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            ch.lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            nm.createNotificationChannel(ch)
            nm.deleteNotificationChannel(OLD_CHANNEL)
        }
    }

    private fun alarmIntent(ctx: Context): PendingIntent = PendingIntent.getBroadcast(
        ctx, 0, Intent(ctx, NotifReceiver::class.java),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    /** Programme le prochain rappel à venir (une seule alarme à la fois, reprogrammée après chaque rappel). */
    fun schedule(ctx: Context) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val now = System.currentTimeMillis()
        val arr = plan(ctx)
        var next = Long.MAX_VALUE
        for (i in 0 until arr.length()) {
            val at = arr.getJSONObject(i).optLong("at", 0L)
            if (at > now && at < next) next = at
        }
        val pi = alarmIntent(ctx)
        am.cancel(pi)
        if (next != Long.MAX_VALUE) {
            // Alarme exacte (sans permission spéciale) : la sonnerie retentit à l'heure de la tâche
            try {
                val show = PendingIntent.getActivity(
                    ctx, 1, Intent(ctx, MainActivity::class.java),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                am.setAlarmClock(AlarmManager.AlarmClockInfo(next, show), pi)
            } catch (e: Exception) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, pi)
            }
        }
    }

    /** Affiche les rappels échus (dans les 12 dernières heures, jamais deux fois), puis programme le suivant. */
    fun fire(ctx: Context) {
        createChannel(ctx)
        val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        val last = prefs.getLong(KEY_LAST, 0L)
        val arr = plan(ctx)
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val at = o.optLong("at", 0L)
            if (at <= now && at > last && now - at <= WINDOW_MS) {
                val title = o.optString("title", "RÉSEAU GOUHONEMAN GROUP")
                val body = o.optString("body", "")
                val n = NotificationCompat.Builder(ctx, CHANNEL)
                    .setSmallIcon(android.R.drawable.ic_popup_reminder)
                    .setContentTitle(title)
                    .setContentText(body.lineSequence().firstOrNull() ?: "")
                    .setStyle(NotificationCompat.BigTextStyle().bigText(body))
                    .setContentIntent(open)
                    .setAutoCancel(true)
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setCategory(NotificationCompat.CATEGORY_REMINDER)
                    .setDefaults(NotificationCompat.DEFAULT_ALL)
                    .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                    .build()
                try {
                    nm.notify((at / 60000L).toInt(), n)
                } catch (e: SecurityException) {
                    // permission de notification refusée : rien à afficher
                }
            }
        }
        prefs.edit().putLong(KEY_LAST, now).apply()
        schedule(ctx)
    }
}

class NotifReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        Notifier.fire(context)
    }
}

/** Après un redémarrage du téléphone ou une mise à jour de l'application : reprogramme les rappels. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        Notifier.fire(context)
    }
}
